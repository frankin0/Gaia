<?php

	/**
	*	Config file 
	*/
	
	$source = __DIR__."\Test";
	$destination = __DIR__.".\..\..\..\Test\\"; 
	
	if ( is_dir( $source ) ) {
		@mkdir( $destination );
		$directory = dir( $source );
		while ( FALSE !== ( $readdirectory = $directory->read() ) ) {
			if ( $readdirectory == '.' || $readdirectory == '..' ) {
				continue;
			}
			$PathDir = $source . '/' . $readdirectory; 
			if ( is_dir( $PathDir ) ) {
				
				echo "<li>Coping file ".$readdirectory."...</li>";
				continue;
			}
			copy( $PathDir, $destination . '/' . $readdirectory );
			echo "<li>Coping file ".$readdirectory."...</li>";
		}

		$directory->close();
	}else {
		copy( $source, $destination );
	}